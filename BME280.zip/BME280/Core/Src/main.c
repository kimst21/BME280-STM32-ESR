/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * - 이 코드는 BME280 센서를 사용하여 온도, 습도, 기압 데이터를 측정합니다.
  * - 측정된 데이터를 SSD1306 OLED 디스플레이에 표시합니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"          // STM32 시스템 초기화 및 주변장치 관련 헤더
#include "i2c.h"           // I2C 통신 설정 및 제어 관련 헤더
#include "gpio.h"          // GPIO 초기화 관련 헤더

/* Private includes ----------------------------------------------------------*/
#include <stdio.h>         // 문자열 처리 및 데이터 출력 관련 라이브러리
#include <string.h>        // 문자열 처리 함수 사용
#include "bme280.h"        // BME280 센서 라이브러리
#include "fonts.h"         // OLED 디스플레이 글꼴 라이브러리
#include "ssd1306.h"       // SSD1306 OLED 디스플레이 제어 라이브러리

/* USER CODE BEGIN 0 */
// 전역 변수 선언: 온도, 습도, 기압 값을 저장할 변수
float temperature;
float humidity;
float pressure;

// BME280 센서 장치 구조체와 센서 데이터 구조체
struct bme280_dev dev;
struct bme280_data comp_data;

// I2C 통신 관련 함수
int8_t user_i2c_read(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len)
{
    // I2C를 통해 BME280의 레지스터를 읽어오는 사용자 정의 함수
    if (HAL_I2C_Master_Transmit(&hi2c3, (id << 1), &reg_addr, 1, 10) != HAL_OK)
        return -1;
    if (HAL_I2C_Master_Receive(&hi2c3, (id << 1) | 0x01, data, len, 10) != HAL_OK)
        return -1;
    return 0;
}

int8_t user_i2c_write(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len)
{
    // I2C를 통해 BME280의 레지스터에 데이터를 쓰는 사용자 정의 함수
    uint8_t buf[len + 1];
    buf[0] = reg_addr;
    memcpy(buf + 1, data, len);
    if (HAL_I2C_Master_Transmit(&hi2c3, (id << 1), buf, len + 1, HAL_MAX_DELAY) != HAL_OK)
        return -1;
    return 0;
}

void user_delay_ms(uint32_t period)
{
    // 지정된 시간(ms) 동안 대기
    HAL_Delay(period);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* USER CODE BEGIN 1 */
    // 프로그램 시작 전 사용자 정의 변수 초기화 가능
    int8_t rslt;
    char hum_string[50];
    char temp_string[50];
    char press_string[50];
    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/
    HAL_Init();                      // HAL 라이브러리 초기화
    SystemClock_Config();            // 시스템 클럭 설정

    /* Initialize all configured peripherals */
    MX_GPIO_Init();                  // GPIO 핀 초기화
    MX_I2C3_Init();                  // I2C3 초기화

    /* USER CODE BEGIN 2 */
    // BME280 센서 초기화
    dev.dev_id = BME280_I2C_ADDR_PRIM;       // BME280 기본 I2C 주소 설정
    dev.intf = BME280_I2C_INTF;              // I2C 인터페이스 사용
    dev.read = user_i2c_read;                // 사용자 정의 I2C 읽기 함수 연결
    dev.write = user_i2c_write;              // 사용자 정의 I2C 쓰기 함수 연결
    dev.delay_ms = user_delay_ms;            // 사용자 정의 딜레이 함수 연결

    rslt = bme280_init(&dev);                // BME280 센서 초기화

    // BME280 센서 설정
    dev.settings.osr_h = BME280_OVERSAMPLING_1X;   // 습도 오버샘플링 설정
    dev.settings.osr_p = BME280_OVERSAMPLING_16X;  // 기압 오버샘플링 설정
    dev.settings.osr_t = BME280_OVERSAMPLING_2X;   // 온도 오버샘플링 설정
    dev.settings.filter = BME280_FILTER_COEFF_16;  // 필터 계수 설정
    rslt = bme280_set_sensor_settings(BME280_OSR_PRESS_SEL | BME280_OSR_TEMP_SEL | BME280_OSR_HUM_SEL | BME280_FILTER_SEL, &dev);

    SSD1306_Init();                  // SSD1306 OLED 초기화
    /* USER CODE END 2 */

    /* Infinite loop */
    while (1)
    {
        /* USER CODE BEGIN WHILE */
        // BME280 강제 모드 설정
        rslt = bme280_set_sensor_mode(BME280_FORCED_MODE, &dev);
        dev.delay_ms(40);                                   // 데이터 측정 대기
        rslt = bme280_get_sensor_data(BME280_ALL, &comp_data, &dev); // 센서 데이터 읽기

        if (rslt == BME280_OK) // 데이터 읽기가 성공하면
        {
            temperature = comp_data.temperature / 100.0; // 온도 변환 (°C)
            humidity = comp_data.humidity / 1024.0;      // 습도 변환 (%)
            pressure = comp_data.pressure / 10000.0;     // 기압 변환 (hPa)

            // 문자열 생성
            sprintf(hum_string, "Humidity %03.1f %% ", humidity);  // 습도 문자열 생성
            sprintf(temp_string, "Temperature %03.1f C ", temperature); // 온도 문자열 생성
            sprintf(press_string, "Pressure %03.1f hPa ", pressure);    // 기압 문자열 생성

            // OLED 디스플레이에 데이터 출력
            SSD1306_GotoXY(0, 0);
            SSD1306_Puts(hum_string, &Font_7x10, 1); // 습도 출력
            SSD1306_GotoXY(0, 20);
            SSD1306_Puts(temp_string, &Font_7x10, 1); // 온도 출력
            SSD1306_GotoXY(0, 40);
            SSD1306_Puts(press_string, &Font_7x10, 1); // 기압 출력
            SSD1306_UpdateScreen();              // OLED 화면 업데이트
        }

        HAL_Delay(1000); // 1초 간격으로 데이터 갱신
        /* USER CODE END WHILE */
    }
    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
